window.onload = function () {
    alert("Bienvenidos a esta web.")
    const name1 = prompt("Enter a fruit:", "fruit...").trim();

    alert(`I like ${name1}.`);
    
}
